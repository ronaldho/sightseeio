 /*#Which of the following statements can replace< missing statement> in
  * the following BDayParty constructor?
  */
 import java.util.List;

 public class Problem34
    {
    
    public class Party
      {
      private List< String > theGuests;
      public Party()
         {
         theGuests = null;
         } //end Party()
         
      public Party( List<String> guests )
         {
         theGuests = guests;
         } //end Party
         
      public void setGuests( List<String> guests )
         {
         theGuests = guests;
         } //end setGuests()
         
      public String toString()
         {
         return "Whatever";
         } //end toString()
      } //end Party
      
    public class BDayParty extends Party
      {
      private String theName;
      
      public BDayParty( String name, List<String> guests )
         {
         super(guests);
         theName = name;
         } //end BDayParty
         
      public String getName()
         {
         return theName;
         } //end getName()
      } //end class
    } //end Problem34
    
    /*
     * The answer is D. Both super(guests) and setGuests(guests)
     * compile because you may call a superclass's constructor
     * and the child classes of Party will inherit the method
     * setGuests. However, you cannot set guests to theGuests
     * because theGuests has private access in the superclass.
     * In order to compile, one should set the variable to protected
     * (only in special circumstances) or write a getter and 
     * setter (setGuests).
     */