/*#Party's toString method lists all the entries in the theGuests list.
 * Should the programmer use a "for-each" loop or the list's get(i)
 * method within a loop to traverse the list?
 */

 public class Problem36
   {
   /*
    * The answer for this problem is E. Honestly, I believe this was
    * overthinking on my part. Of course, both methods are equally
    * efficient; however, I was thinking more from the byte or bit
    * perspective. I thought that a for-each loop would require less
    * code than the get() method for a list and this would
    * result in better efficiency. After thinking about this,
    * I realized that if there is any difference in efficiency, it would
    * most likely be negligable. Therefore, the answer is that both ways
    * are equally efficient.
    */
   } //end Problem36