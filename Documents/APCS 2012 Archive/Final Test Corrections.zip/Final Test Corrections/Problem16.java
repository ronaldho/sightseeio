/*# Which of the following code segments correctly traverses a
 * two dimensional array int array m, row by row?
 */

public class Problem16
   {
   public static void main( String[] args )
      {
      int[][] m = new int[5][5];
      int counter = 0;
      
      //B
       for( int[] r : m )
         {
         for( int x : r )
            {
            System.out.print( "hi\t" );
            } //end nested for
            System.out.println( "\n" );
         } //end for
         
      //C
      /*for( int r : m )
         {
         for( int[] x : r )
            {
            System.out.println( "hi \t" );
            counter++;
            } //end nested for
         } //end for */
         
      //E
      /*for( int c = 0; c < m.length; c++ )
         {
         for( int r = 0; r < m[c].length; r++ )
            {
            int x = m[r][c];
            System.out.print( x + "\t" );
            } //end nested for
            System.out.println( "\n" ); 
         } //end for */
         
      
         
      //System.out.println("\n\n\n" + counter );
      } //end main
   } //end Problem16
   
   //The answer is not A because there is no nested for loop to traverse
   //the second dimension of the array
   
   //The answer IS B because as you see in the running example above,
   //hi is printed out 25 times (the length of the array and the counter 
   //indicates that.
   
   //The answer is not C because the first for loop is attempting to
   //traverse a one-dimensional array which there is none.
   
   //The answer is not D because, once again, the first for loop
   //attempts to traverse a one-dimensional array instead of
   //one dimension of a two-dimensional array.
   
   //The answer is not E. Although the array is traversed without problems
   //int x is set to the default values of each array section (0).
   
   
   
   